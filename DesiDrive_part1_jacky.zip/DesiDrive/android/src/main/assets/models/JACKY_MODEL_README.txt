OPTIONAL: real rigged Jacky model
=================================
Drop ONE of these here and the game uses it instead of the built-in procedural Jacky:

  jacky.g3db   (preferred, binary libGDX format, supports skeleton + animations)
  jacky.g3dj   (same, JSON)
  jacky.obj    (static, NOT animated - fallback only)

Requirements for jacky.g3db / jacky.g3dj
  - Humanoid facing +Z, Y up, feet near the bottom (it is auto-scaled to 1.8 m and auto-grounded)
  - Skinned with at most 40 bones (JackyAssets.MAX_BONES). More than that -> built-in Jacky is used.
  - Animation clip names containing: "idle", "walk", "run" (or "jog"/"sprint"), case-insensitive
  - Textures referenced by the model must sit next to it in this folder

How to produce a g3db: export FBX/glTF from Blender (or Mixamo), then convert with libGDX fbx-conv
(https://github.com/libgdx/fbx-conv) :   fbx-conv -f -o G3DB jacky.fbx jacky.g3db

Look to model: Indian male ~23, muscular, mullet with short faded sides, light stubble, black jacket,
black fitted tee, black cargo trousers, sneakers, silver chain, wristwatch, black sunglasses.
