package com.desidrive.game

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.attributes.FloatAttribute
import com.badlogic.gdx.graphics.g3d.attributes.IntAttribute
import com.badlogic.gdx.graphics.g3d.loader.G3dModelLoader
import com.badlogic.gdx.graphics.g3d.loader.ObjLoader
import com.badlogic.gdx.graphics.g3d.model.Node
import com.badlogic.gdx.graphics.g3d.utils.AnimationController
import com.badlogic.gdx.graphics.g3d.utils.MeshBuilder
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.math.collision.BoundingBox
import com.badlogic.gdx.utils.JsonReader
import com.badlogic.gdx.utils.UBJsonReader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/*
 * JACKY - the hero.  Visual only: DesiGame still owns movement, collision, camera, missions etc.
 *
 * Same public surface the old hero (Human) had:  x, z, yaw, anim, moving, amp, parts, layout().
 *
 * Two rendering paths:
 *   1. If assets/models/jacky.g3db (or .g3dj) exists  -> real rigged humanoid, played with libGDX
 *      AnimationController (clips are looked up by name: idle / walk / run).
 *      assets/models/jacky.obj is accepted as a static, un-animated fallback.
 *   2. Otherwise -> procedural Jacky: ~12 articulated, smoothly lofted body parts (not boxes) with
 *      mullet, stubble, jacket + tee, cargo pants, sneakers, chain, watch and sunglasses.
 *      This is still generated geometry, NOT a sculpted/photoreal model.
 */

// ------------------------------------------------------------------------------------------------
// Look switches
// ------------------------------------------------------------------------------------------------
object JackyLook {
    const val SUNGLASSES = true
    const val STUBBLE = true
    const val CHAIN = true
    const val WATCH = true
}

// ------------------------------------------------------------------------------------------------
// Public hero class
// ------------------------------------------------------------------------------------------------
class Jacky {
    var x = 0f; var z = 0f; var yaw = 0f
    var anim = 0f; var moving = false; var amp = 38f

    private val ext: ExtJacky? = JackyAssets.load()
    private val proc: ProcJacky? = if (ext == null) ProcJacky() else null

    /** True when a real imported model is being used (false = procedural body). */
    val usingImportedModel: Boolean get() = ext != null

    val parts: List<ModelInstance> = ext?.parts ?: proc!!.parts

    fun layout() {
        val dt = min(Gdx.graphics.deltaTime, 0.05f)
        val e = ext
        if (e != null) e.layout(this, dt) else proc!!.layout(this, dt)
    }
}

// ------------------------------------------------------------------------------------------------
// Imported (rigged) model support
// ------------------------------------------------------------------------------------------------
internal class ExtJacky(
    val inst: ModelInstance, val k: Float, val ox: Float, val oy: Float, val oz: Float,
    val ctrl: AnimationController?, val idle: String?, val walk: String?, val run: String?
) {
    val parts: List<ModelInstance> = listOf(inst)
    private var cur: String? = null

    fun layout(j: Jacky, dt: Float) {
        inst.transform.idt().translate(j.x, 0f, j.z).rotate(Vector3.Y, j.yaw)
            .scale(k, k, k).translate(-ox, -oy, -oz)
        val c = ctrl ?: return
        val want: String? =
            if (!j.moving) (idle ?: walk)
            else if (j.amp >= 44f && run != null) run
            else (walk ?: run)
        if (want != null && want != cur) {
            cur = want
            c.animate(want, -1, 1f, null, 0.2f)
        }
        c.paused = !j.moving && idle == null
        if (j.moving) c.current?.speed = (j.amp / (if (cur == run) 56f else 34f)).coerceIn(0.6f, 1.8f)
        c.update(dt)
    }
}

object JackyAssets {
    /** Must match the shader config in DesiGame (DefaultShader/DepthShader numBones). */
    const val MAX_BONES = 40
    /** Imported model is scaled so its bind-pose height equals this (metres). */
    const val HEIGHT = 1.80f

    private fun maxBones(nodes: Iterable<Node>): Int {
        var m = 0
        for (n in nodes) {
            for (p in n.parts) {
                val b = p.invBoneBindTransforms
                if (b != null && b.size > m) m = b.size
            }
            m = max(m, maxBones(n.children))
        }
        return m
    }

    private fun loadModel(): Model? {
        val g3db = Gdx.files.internal("models/jacky.g3db")
        if (g3db.exists()) return G3dModelLoader(UBJsonReader()).loadModel(g3db)
        val g3dj = Gdx.files.internal("models/jacky.g3dj")
        if (g3dj.exists()) return G3dModelLoader(JsonReader()).loadModel(g3dj)
        val obj = Gdx.files.internal("models/jacky.obj")
        if (obj.exists()) return ObjLoader().loadModel(obj)
        return null
    }

    internal fun load(): ExtJacky? {
        try {
            val model = loadModel() ?: return null
            val bones = maxBones(model.nodes)
            if (bones > MAX_BONES) {
                Gdx.app.log("Jacky", "Model has $bones bones (> $MAX_BONES). Using built-in Jacky instead.")
                model.dispose()
                return null
            }
            val bb = model.calculateBoundingBox(BoundingBox())
            val dim = Vector3(); val ctr = Vector3()
            bb.getDimensions(dim); bb.getCenter(ctr)
            if (dim.y <= 0.0001f) { model.dispose(); return null }
            Gfx.track(model)
            val inst = ModelInstance(model)
            var idle: String? = null; var walk: String? = null; var run: String? = null
            for (a in inst.animations) {
                val n = a.id.lowercase()
                if (idle == null && n.contains("idle")) idle = a.id
                else if (walk == null && n.contains("walk")) walk = a.id
                else if (run == null && (n.contains("run") || n.contains("jog") || n.contains("sprint"))) run = a.id
            }
            val ctrl = if (inst.animations.size > 0) AnimationController(inst) else null
            Gdx.app.log("Jacky", "Imported model loaded: bones=$bones idle=$idle walk=$walk run=$run")
            return ExtJacky(inst, HEIGHT / dim.y, ctr.x, bb.min.y, ctr.z, ctrl, idle, walk, run)
        } catch (t: Throwable) {
            Gdx.app.log("Jacky", "Could not load imported model, using built-in Jacky: $t")
            return null
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Procedural geometry helpers (smooth lofted tubes with vertex colours)
// ------------------------------------------------------------------------------------------------
/** One cross-section of a loft. Ring is elliptical: rx across, rf/rb front/back half-depth. */
private class Sec(val pos: Float, val rx: Float, val rf: Float, val rb: Float, val cx: Float, val cz: Float)

private fun sec(pos: Float, rx: Float, r: Float, cx: Float = 0f, cz: Float = 0f) = Sec(pos, rx, r, r, cx, cz)

/** Section described by absolute front / back extents along Z (used for the head and hair). */
private fun secZ(pos: Float, rx: Float, zf: Float, zb: Float, cx: Float = 0f): Sec {
    val r = (zf - zb) * 0.5f
    return Sec(pos, rx, r, r, cx, (zf + zb) * 0.5f)
}

private fun hex(s: String): Color = Color.valueOf(s)
private fun mix(a: Color, b: Color, t: Float): Color = Color(a).lerp(b, t.coerceIn(0f, 1f))
private fun noise(a: Float, b: Float): Float {
    val v = sin(a * 12.9898f + b * 78.233f) * 43758.5453f
    return v - floor(v)
}

private object Mesher {
    const val N = 24
    private val vi = MeshPartBuilder.VertexInfo()
    private val tp = Vector3()
    private val tn = Vector3()
    private val tuv = Vector2()
    private val tm = Matrix4()

    /**
     * Lofts [secs] into a closed, capped tube. axisZ=false: tube runs along Y (ring in X/Z, front = +Z).
     * axisZ=true: tube runs along Z (ring in X/Y, "front" = +Y), used for shoes.
     * col(theta, pos): theta in (-PI, PI], 0 = front. inset(theta, pos) pulls the surface inwards.
     */
    fun loft(
        b: MeshBuilder, secs: List<Sec>, axisZ: Boolean,
        col: (Float, Float) -> Color,
        inset: ((Float, Float) -> Float)? = null
    ) {
        val s = secs.size
        val px = FloatArray(s * N); val py = FloatArray(s * N); val pz = FloatArray(s * N)
        val ts = FloatArray(N) { val t = it * MathUtils.PI2 / N; if (t > MathUtils.PI) t - MathUtils.PI2 else t }
        for (i in 0 until s) {
            val sc = secs[i]
            for (j in 0 until N) {
                val t = ts[j]
                val sn = sin(t); val cs = cos(t)
                val k = inset?.invoke(t, sc.pos) ?: 0f
                val a = sn * max(0.001f, sc.rx - k) + sc.cx
                val r = if (cs >= 0f) sc.rf else sc.rb
                val c = cs * max(0.001f, r - k) + sc.cz
                val id = i * N + j
                if (!axisZ) { px[id] = a; py[id] = sc.pos; pz[id] = c }
                else { px[id] = a; py[id] = c; pz[id] = sc.pos }
            }
        }
        val idx = ShortArray(s * N)
        for (i in 0 until s) {
            val sc = secs[i]
            val cxw = sc.cx
            val cyw = if (axisZ) sc.cz else sc.pos
            val czw = if (axisZ) sc.pos else sc.cz
            for (j in 0 until N) {
                val id = i * N + j
                val jp = i * N + (j + 1) % N
                val jm = i * N + (j + N - 1) % N
                val ip = min(i + 1, s - 1) * N + j
                val im = max(i - 1, 0) * N + j
                val ux = px[jp] - px[jm]; val uy = py[jp] - py[jm]; val uz = pz[jp] - pz[jm]
                val vx = px[ip] - px[im]; val vy = py[ip] - py[im]; val vz = pz[ip] - pz[im]
                var nx = uy * vz - uz * vy
                var ny = uz * vx - ux * vz
                var nz = ux * vy - uy * vx
                val ox = px[id] - cxw; val oy = py[id] - cyw; val oz = pz[id] - czw
                if (nx * ox + ny * oy + nz * oz < 0f) { nx = -nx; ny = -ny; nz = -nz }
                if (nx * nx + ny * ny + nz * nz < 1e-12f) { nx = ox; ny = oy; nz = oz }
                if (nx * nx + ny * ny + nz * nz < 1e-12f) { nx = 0f; ny = 1f; nz = 0f }
                tn.set(nx, ny, nz).nor()
                vi.set(tp.set(px[id], py[id], pz[id]), tn, col(ts[j], sc.pos), tuv.set(0f, 0f))
                idx[id] = b.vertex(vi)
            }
        }
        for (i in 0 until s - 1) for (j in 0 until N) {
            val jn = (j + 1) % N
            val a = idx[i * N + j]; val bb = idx[i * N + jn]
            val c = idx[(i + 1) * N + jn]; val d = idx[(i + 1) * N + j]
            b.triangle(a, bb, c)
            b.triangle(a, c, d)
        }
        // end caps (culling is disabled on the material, so winding does not matter)
        val dir = if (secs[s - 1].pos >= secs[0].pos) 1f else -1f
        for (end in 0..1) {
            val sc = if (end == 0) secs[0] else secs[s - 1]
            val sgn = if (end == 0) -dir else dir
            val cy = if (axisZ) sc.cz else sc.pos
            val cz = if (axisZ) sc.pos else sc.cz
            tn.set(0f, if (axisZ) 0f else sgn, if (axisZ) sgn else 0f)
            vi.set(tp.set(sc.cx, cy, cz), tn, col(0f, sc.pos), tuv.set(0f, 0f))
            val ci = b.vertex(vi)
            val row = if (end == 0) 0 else s - 1
            for (j in 0 until N) b.triangle(ci, idx[row * N + j], idx[row * N + (j + 1) % N])
        }
    }

    fun box(
        b: MeshBuilder, c: Color, x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float,
        rx: Float = 0f, ry: Float = 0f, rz: Float = 0f
    ) {
        tm.idt().translate(x, y, z)
        if (ry != 0f) tm.rotate(Vector3.Y, ry)
        if (rx != 0f) tm.rotate(Vector3.X, rx)
        if (rz != 0f) tm.rotate(Vector3.Z, rz)
        b.setColor(c); b.setVertexTransform(tm)
        b.box(sx, sy, sz)
        b.setVertexTransform(null)
    }

    fun ball(b: MeshBuilder, c: Color, x: Float, y: Float, z: Float, dx: Float, dy: Float, dz: Float) {
        tm.idt().translate(x, y, z)
        b.setColor(c); b.setVertexTransform(tm)
        b.sphere(dx, dy, dz, 10, 8)
        b.setVertexTransform(null)
    }
}

// ------------------------------------------------------------------------------------------------
// Colours
// ------------------------------------------------------------------------------------------------
private val SKIN = hex("bf7f48")
private val SKIN_DK = hex("a96c3c")
private val HAIR = hex("17100c")
private val HAIR_HI = hex("3b2a1e")
private val JACKET = hex("131417")
private val JACKET_HEM = hex("1c1d21")
private val SHIRT = hex("2a2c32")
private val PANTS = hex("1e1f23")
private val POCKET = hex("27282d")
private val SILVER = hex("c9ccd4")
private val LIP = hex("80433a")

// ------------------------------------------------------------------------------------------------
// Procedural model parts (built once, shared)
// ------------------------------------------------------------------------------------------------
private object JackyModels {
    private val material: Material = Material(
        ColorAttribute.createDiffuse(Color.WHITE),
        ColorAttribute.createSpecular(0.16f, 0.16f, 0.16f, 1f),
        FloatAttribute.createShininess(16f),
        IntAttribute.createCullFace(0)            // 0 = no culling: robust against winding mistakes
    )

    private fun build(name: String, f: (MeshBuilder) -> Unit): Model {
        val b = MeshBuilder()
        b.begin(Gfx.AT, GL20.GL_TRIANGLES)
        f(b)
        val mesh = b.end()
        val mdl = ModelBuilder()
        mdl.begin()
        mdl.part(name, mesh, GL20.GL_TRIANGLES, material)
        val m = mdl.end()
        Gfx.track(m)
        return m
    }

    private fun flat(c: Color): (Float, Float) -> Color = { _, _ -> c }

    // ---- key heights (metres, feet at y = 0) ----
    const val HIP_Y = 0.93f
    const val SHOULDER_X = 0.262f
    const val SHOULDER_Y = 1.395f
    const val HIP_X = 0.098f
    const val THIGH_LEN = 0.43f
    const val UPPER_ARM_LEN = 0.30f

    // ---- torso: jacket (open at the front, tee visible), neck, collar, chain ----
    private val torsoSecs = listOf(
        Sec(0.870f, 0.190f, 0.120f, 0.112f, 0f, 0f),
        Sec(0.930f, 0.194f, 0.120f, 0.112f, 0f, 0f),
        Sec(1.050f, 0.200f, 0.118f, 0.110f, 0f, 0f),
        Sec(1.180f, 0.220f, 0.128f, 0.116f, 0f, 0f),
        Sec(1.290f, 0.240f, 0.138f, 0.120f, 0f, 0f),
        Sec(1.370f, 0.246f, 0.136f, 0.116f, 0f, 0f),
        Sec(1.420f, 0.232f, 0.118f, 0.104f, 0f, 0f),
        Sec(1.455f, 0.170f, 0.090f, 0.082f, 0f, 0f),
        Sec(1.485f, 0.095f, 0.066f, 0.064f, 0f, 0f),
        Sec(1.505f, 0.072f, 0.060f, 0.060f, 0f, 0f)
    )

    private fun torsoFront(y: Float): Float {
        // interpolate front half-depth of the jacket at height y
        val s = torsoSecs
        if (y <= s[0].pos) return s[0].rf
        for (i in 0 until s.size - 1) {
            if (y <= s[i + 1].pos) {
                val t = (y - s[i].pos) / (s[i + 1].pos - s[i].pos)
                return s[i].rf + (s[i + 1].rf - s[i].rf) * t
            }
        }
        return s[s.size - 1].rf
    }

    private fun isOpen(t: Float, y: Float): Boolean =
        y in 0.86f..1.52f && abs(t) < (0.12f + 0.30f * ((1.50f - y) / 0.57f).coerceIn(0f, 1f))

    val torso: Model by lazy {
        build("jacky_torso") { b ->
            Mesher.loft(b, torsoSecs, false, { t, y ->
                if (isOpen(t, y)) SHIRT
                else {
                    val base = if (y < 0.905f) JACKET_HEM else JACKET
                    val n = (noise(t * 7f, y * 31f) - 0.5f) * 0.03f
                    Color(base.r + n, base.g + n, base.b + n, 1f)
                }
            }, { t, y -> if (isOpen(t, y)) 0.022f else 0f })

            // neck (skin) and tee crew-neck ring
            Mesher.loft(b, listOf(
                sec(1.430f, 0.060f, 0.058f, 0f, -0.006f), sec(1.500f, 0.052f, 0.054f, 0f, -0.008f),
                sec(1.560f, 0.050f, 0.052f, 0f, -0.010f), sec(1.595f, 0.052f, 0.056f, 0f, -0.010f)
            ), false, flat(SKIN), null)
            Mesher.loft(b, listOf(
                sec(1.478f, 0.064f, 0.062f, 0f, -0.006f), sec(1.505f, 0.067f, 0.065f, 0f, -0.007f),
                sec(1.530f, 0.063f, 0.061f, 0f, -0.008f)
            ), false, flat(SHIRT), null)

            // jacket collar flaps + back collar
            for (sx in intArrayOf(-1, 1)) {
                Mesher.box(b, JACKET, sx * 0.072f, 1.500f, 0.050f, 0.075f, 0.075f, 0.024f, -12f, sx * 26f, sx * 6f)
                Mesher.box(b, JACKET_HEM, sx * 0.150f, 1.020f, 0.125f, 0.075f, 0.012f, 0.014f, 0f, sx * 8f, 0f) // pocket slit
                Mesher.ball(b, SILVER, sx * 0.188f, 1.040f, 0.114f, 0.016f, 0.016f, 0.012f)                    // zip pull
            }
            Mesher.box(b, JACKET, 0f, 1.515f, -0.062f, 0.150f, 0.075f, 0.030f, 8f)

            // silver chain on the tee + pendant
            if (JackyLook.CHAIN) {
                val n = 15
                for (i in 0 until n) {
                    val s = (i / (n - 1f)) * 2f - 1f
                    val y = 1.488f - 0.115f * (1f - s * s)
                    val x = s * 0.056f
                    val zz = torsoFront(y) - 0.022f + 0.009f
                    Mesher.ball(b, SILVER, x, y, zz, 0.014f, 0.014f, 0.014f)
                }
                val py = 1.488f - 0.115f - 0.022f
                Mesher.box(b, SILVER, 0f, py, torsoFront(py) - 0.022f + 0.011f, 0.020f, 0.032f, 0.008f, -8f)
            }
        }
    }

    // ---- hips / pelvis (trousers) ----
    val hips: Model by lazy {
        build("jacky_hips") { b ->
            Mesher.loft(b, listOf(
                Sec(0.760f, 0.170f, 0.100f, 0.104f, 0f, 0f), Sec(0.860f, 0.188f, 0.112f, 0.112f, 0f, 0f),
                Sec(0.930f, 0.190f, 0.114f, 0.112f, 0f, 0f), Sec(0.965f, 0.186f, 0.110f, 0.108f, 0f, 0f)
            ), false, { t, y -> val n = (noise(t * 5f, y * 17f) - 0.5f) * 0.02f; Color(PANTS.r + n, PANTS.g + n, PANTS.b + n, 1f) }, null)
        }
    }

    // ---- head ----
    private val headSecs = listOf(
        secZ(1.545f, 0.028f, 0.058f, 0.018f), secZ(1.562f, 0.058f, 0.083f, -0.020f),
        secZ(1.585f, 0.080f, 0.090f, -0.072f), secZ(1.617f, 0.086f, 0.094f, -0.094f),
        secZ(1.655f, 0.087f, 0.096f, -0.102f), secZ(1.692f, 0.085f, 0.094f, -0.104f),
        secZ(1.730f, 0.078f, 0.084f, -0.099f), secZ(1.760f, 0.060f, 0.066f, -0.084f),
        secZ(1.780f, 0.034f, 0.038f, -0.052f), secZ(1.790f, 0.008f, 0.010f, -0.014f)
    )

    // Modern mullet: short faded sides, big volume on top/front, long tail at the back.
    private val hairSecs = listOf(
        secZ(1.640f, 0.090f, 0.060f, -0.108f), secZ(1.690f, 0.088f, 0.080f, -0.110f),
        secZ(1.725f, 0.083f, 0.082f, -0.108f), secZ(1.752f, 0.076f, 0.082f, -0.100f),
        secZ(1.775f, 0.082f, 0.100f, -0.110f), secZ(1.805f, 0.078f, 0.112f, -0.112f),
        secZ(1.830f, 0.062f, 0.102f, -0.100f), secZ(1.848f, 0.038f, 0.070f, -0.070f),
        secZ(1.858f, 0.012f, 0.030f, -0.030f)
    )

    private fun hairColor(t: Float, y: Float): Color {
        val strand = noise(t * 9f, y * 53f)
        var c = mix(HAIR, HAIR_HI, strand * 0.55f)
        if (y > 1.80f && abs(t) < 1.2f) c = mix(c, HAIR_HI, 0.25f)
        if (y < 1.735f && abs(sin(t)) > 0.5f) c = mix(c, SKIN, if (y < 1.66f) 0.55f else 0.35f) // faded sides
        return c
    }

    val head: Model by lazy {
        build("jacky_head") { b ->
            // skull + face with light stubble painted on the lower face
            Mesher.loft(b, headSecs, false, { t, y ->
                var c = SKIN
                if (JackyLook.STUBBLE) {
                    val mY = ((1.652f - y) / 0.03f).coerceIn(0f, 1f)
                    val mA = ((2.15f - abs(t)) / 0.35f).coerceIn(0f, 1f)
                    c = mix(SKIN, hex("2b1d14"), mY * mA * 0.6f)
                }
                c
            }, null)

            // hair
            Mesher.loft(b, hairSecs, false, { t, y -> hairColor(t, y) }, null)
            val tail = listOf(
                secZ(1.665f, 0.072f, -0.060f, -0.114f), secZ(1.620f, 0.074f, -0.062f, -0.118f),
                secZ(1.580f, 0.076f, -0.050f, -0.122f), secZ(1.545f, 0.070f, -0.045f, -0.118f),
                secZ(1.515f, 0.052f, -0.045f, -0.106f), secZ(1.495f, 0.026f, -0.050f, -0.092f),
                secZ(1.486f, 0.005f, -0.060f, -0.080f)
            )
            Mesher.loft(b, tail, false, { t, y -> hairColor(t, y) }, null)
            for (sx in intArrayOf(-1, 1)) {
                Mesher.loft(b, listOf(
                    secZ(1.610f, 0.026f, -0.072f, -0.116f, sx * 0.052f), secZ(1.570f, 0.028f, -0.062f, -0.120f, sx * 0.056f),
                    secZ(1.535f, 0.022f, -0.060f, -0.112f, sx * 0.050f), secZ(1.508f, 0.006f, -0.060f, -0.100f, sx * 0.045f)
                ), false, { t, y -> hairColor(t, y) }, null)
            }

            // ears, nose, mouth, brows
            for (sx in intArrayOf(-1, 1)) {
                Mesher.ball(b, SKIN_DK, sx * 0.0865f, 1.652f, -0.012f, 0.016f, 0.044f, 0.030f)
                Mesher.box(b, HAIR, sx * 0.034f, 1.702f, 0.0855f, 0.040f, 0.009f, 0.014f, 0f, sx * 14f, sx * 8f)
                Mesher.ball(b, SKIN, sx * 0.014f, 1.620f, 0.106f, 0.018f, 0.016f, 0.018f)
            }
            Mesher.box(b, SKIN, 0f, 1.648f, 0.098f, 0.022f, 0.055f, 0.026f, -14f)
            Mesher.ball(b, SKIN, 0f, 1.622f, 0.116f, 0.030f, 0.024f, 0.030f)
            Mesher.box(b, LIP, 0f, 1.598f, 0.0925f, 0.052f, 0.010f, 0.012f)

            if (JackyLook.SUNGLASSES) {
                val frame = hex("060607"); val lens = hex("15171d")
                for (sx in intArrayOf(-1, 1)) {
                    Mesher.box(b, frame, sx * 0.040f, 1.673f, 0.0895f, 0.074f, 0.046f, 0.008f, 0f, sx * 22f)
                    Mesher.box(b, lens, sx * 0.040f, 1.673f, 0.0925f, 0.064f, 0.036f, 0.006f, 0f, sx * 22f)
                    Mesher.box(b, frame, sx * 0.0885f, 1.681f, 0.012f, 0.007f, 0.010f, 0.115f)   // temple arm
                }
                Mesher.box(b, frame, 0f, 1.682f, 0.0960f, 0.024f, 0.010f, 0.010f)               // nose bridge
            } else {
                for (sx in intArrayOf(-1, 1)) {
                    Mesher.ball(b, hex("f2efe9"), sx * 0.036f, 1.672f, 0.084f, 0.022f, 0.012f, 0.012f)
                    Mesher.ball(b, hex("120d0a"), sx * 0.036f, 1.672f, 0.0895f, 0.011f, 0.011f, 0.006f)
                }
            }
        }
    }

    // ---- arms (jacket sleeves + skin forearm/hand) ----
    val upperArm: Model by lazy {
        build("jacky_upper_arm") { b ->
            Mesher.loft(b, listOf(
                sec(0.060f, 0.060f, 0.060f), sec(0.000f, 0.082f, 0.076f), sec(-0.080f, 0.080f, 0.074f),
                sec(-0.170f, 0.078f, 0.072f), sec(-0.250f, 0.066f, 0.062f), sec(-0.305f, 0.060f, 0.058f)
            ), false, { t, y -> val n = (noise(t * 6f, y * 29f) - 0.5f) * 0.03f; Color(JACKET.r + n, JACKET.g + n, JACKET.b + n, 1f) }, null)
        }
    }

    /** sx = +1: character's left arm (+X), carries the wristwatch. */
    fun foreArm(sx: Int): Model = build(if (sx > 0) "jacky_fore_l" else "jacky_fore_r") { b ->
        Mesher.loft(b, listOf(
            sec(0.030f, 0.058f, 0.056f), sec(-0.040f, 0.062f, 0.058f), sec(-0.120f, 0.060f, 0.056f),
            sec(-0.200f, 0.053f, 0.049f), sec(-0.242f, 0.054f, 0.050f)
        ), false, { t, y -> val n = (noise(t * 6f, y * 29f) - 0.5f) * 0.03f; Color(JACKET.r + n, JACKET.g + n, JACKET.b + n, 1f) }, null)
        // wrist + hand
        Mesher.loft(b, listOf(sec(-0.236f, 0.036f, 0.032f), sec(-0.290f, 0.034f, 0.031f)), false, flat(SKIN), null)
        Mesher.loft(b, listOf(
            sec(-0.285f, 0.020f, 0.040f), sec(-0.340f, 0.020f, 0.042f), sec(-0.375f, 0.017f, 0.038f)
        ), false, flat(SKIN), null)
        Mesher.loft(b, listOf(
            sec(-0.370f, 0.017f, 0.037f), sec(-0.420f, 0.015f, 0.034f, 0f, 0.008f), sec(-0.452f, 0.008f, 0.022f, 0f, 0.016f)
        ), false, flat(SKIN_DK), null)
        Mesher.box(b, SKIN, -sx * 0.020f, -0.335f, 0.042f, 0.016f, 0.055f, 0.018f, -10f)          // thumb
        if (sx > 0 && JackyLook.WATCH) {
            Mesher.loft(b, listOf(sec(-0.255f, 0.043f, 0.039f), sec(-0.283f, 0.043f, 0.039f)), false, flat(hex("33353b")), null) // strap
            Mesher.box(b, SILVER, 0.044f, -0.269f, 0f, 0.014f, 0.040f, 0.040f)                      // case
            Mesher.box(b, hex("0d0e12"), 0.0525f, -0.269f, 0f, 0.004f, 0.031f, 0.031f)              // dial
            Mesher.box(b, SILVER, 0.0545f, -0.269f, 0.004f, 0.002f, 0.002f, 0.012f)                 // hand
        }
    }

    // ---- legs (black cargo trousers) + sneakers ----
    fun thigh(sx: Int): Model = build(if (sx > 0) "jacky_thigh_l" else "jacky_thigh_r") { b ->
        Mesher.loft(b, listOf(
            sec(0.050f, 0.105f, 0.108f), sec(0.000f, 0.112f, 0.112f), sec(-0.100f, 0.110f, 0.110f),
            sec(-0.220f, 0.098f, 0.100f), sec(-0.330f, 0.086f, 0.088f), sec(-0.435f, 0.078f, 0.080f)
        ), false, { t, y -> val n = (noise(t * 5f, y * 23f) - 0.5f) * 0.02f; Color(PANTS.r + n, PANTS.g + n, PANTS.b + n, 1f) }, null)
        // cargo pocket on the outer side
        Mesher.box(b, POCKET, sx * 0.108f, -0.205f, 0.004f, 0.030f, 0.135f, 0.105f)
        Mesher.box(b, POCKET, sx * 0.111f, -0.150f, 0.004f, 0.034f, 0.032f, 0.110f)   // flap
        Mesher.ball(b, SILVER, sx * 0.1275f, -0.162f, 0.004f, 0.010f, 0.012f, 0.012f)  // snap
    }

    val shin: Model by lazy {
        build("jacky_shin_shoe") { b ->
            // trouser leg (calf bulge to the back, gathered cuff over the shoe)
            Mesher.loft(b, listOf(
                sec(0.020f, 0.078f, 0.080f), sec(-0.060f, 0.074f, 0.078f, 0f, -0.006f),
                sec(-0.180f, 0.066f, 0.070f, 0f, -0.008f), sec(-0.300f, 0.058f, 0.058f),
                sec(-0.372f, 0.060f, 0.060f), sec(-0.408f, 0.062f, 0.062f)
            ), false, { t, y -> val n = (noise(t * 5f, y * 23f) - 0.5f) * 0.02f; Color(PANTS.r + n, PANTS.g + n, PANTS.b + n, 1f) }, null)

            // sneaker upper (runs along Z). local y = -0.50 is the floor.
            val white = hex("ececef"); val dark = hex("18191d"); val lace = hex("cfd0d6")
            fun up(z: Float, rx: Float, ry: Float, cy: Float) = Sec(z, rx, ry, ry, 0f, cy)
            Mesher.loft(b, listOf(
                up(-0.090f, 0.033f, 0.0325f, -0.4325f), up(-0.060f, 0.050f, 0.045f, -0.420f),
                up(-0.020f, 0.052f, 0.040f, -0.425f), up(0.030f, 0.050f, 0.025f, -0.440f),
                up(0.090f, 0.048f, 0.0175f, -0.4475f), up(0.150f, 0.042f, 0.0125f, -0.4525f),
                up(0.185f, 0.025f, 0.010f, -0.455f), up(0.195f, 0.006f, 0.004f, -0.456f)
            ), true, { t, z ->
                when {
                    abs(sin(t)) > 0.80f && z > -0.03f && z < 0.08f -> white                     // side stripe
                    abs(t) < 0.35f && z > -0.01f && z < 0.10f -> lace                           // laces / tongue
                    abs(t) > 2.6f && z < -0.06f -> white                                        // heel tab
                    z > 0.13f -> mix(dark, white, 0.35f)                                        // toe cap
                    else -> dark
                }
            }, null)
            // chunky white sole
            Mesher.loft(b, listOf(
                up(-0.095f, 0.030f, 0.0175f, -0.4825f), up(-0.070f, 0.050f, 0.0175f, -0.4825f),
                up(0.000f, 0.058f, 0.0175f, -0.4825f), up(0.080f, 0.056f, 0.0175f, -0.4825f),
                up(0.150f, 0.046f, 0.0175f, -0.4825f), up(0.190f, 0.028f, 0.0175f, -0.4825f),
                up(0.205f, 0.010f, 0.0175f, -0.4825f)
            ), true, { _, z -> if (z > 0.10f) white else mix(white, hex("d6d7dc"), 0.4f) }, null)
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Procedural Jacky rig + animation
// ------------------------------------------------------------------------------------------------
private class ProcJacky {
    private val hips = ModelInstance(JackyModels.hips)
    private val torso = ModelInstance(JackyModels.torso)
    private val head = ModelInstance(JackyModels.head)
    private val upperA = ModelInstance(JackyModels.upperArm)   // index 0 -> sx = -1
    private val upperB = ModelInstance(JackyModels.upperArm)   // index 1 -> sx = +1
    private val foreA = ModelInstance(JackyModels.foreArm(-1))
    private val foreB = ModelInstance(JackyModels.foreArm(1))
    private val thighA = ModelInstance(JackyModels.thigh(-1))
    private val thighB = ModelInstance(JackyModels.thigh(1))
    private val shinA = ModelInstance(JackyModels.shin)
    private val shinB = ModelInstance(JackyModels.shin)

    val parts: List<ModelInstance> =
        listOf(hips, torso, head, upperA, upperB, foreA, foreB, thighA, thighB, shinA, shinB)

    private var blend = 0f
    private var idleT = 0f
    private val base = Matrix4()
    private val tor = Matrix4()
    private val tmp = Matrix4()

    fun layout(j: Jacky, dt: Float) {
        blend += ((if (j.moving) 1f else 0f) - blend) * min(1f, dt * 8f)
        idleT += dt
        val a = j.amp * blend
        val g = (a / 58f).coerceIn(0f, 1f)
        val run = ((a - 36f) / 22f).coerceIn(0f, 1f)
        val sw = sin(j.anim) * a
        val cw = cos(j.anim)
        val idle = 1f - blend
        val hipY = JackyModels.HIP_Y

        // keep the planted foot near the floor when the stride opens up
        val thighMax = abs(sw) * 0.72f
        val drop = hipY * (1f - cos(thighMax * MathUtils.degreesToRadians)) * 0.6f
        val twist = sw * 0.14f
        val lean = 2.0f + g * 5f + run * 9f + sin(idleT * 2.2f) * 0.6f * idle

        base.idt().translate(j.x, 0f, j.z).rotate(Vector3.Y, j.yaw)

        hips.transform.set(base).translate(0f, -drop, 0f).rotate(Vector3.Y, -twist * 0.6f)

        tor.set(base).translate(0f, hipY - drop, 0f).rotate(Vector3.X, lean).rotate(Vector3.Y, twist)
            .translate(0f, -hipY, 0f)
        torso.transform.set(tor)

        head.transform.set(tor).translate(0f, 1.50f, 0f)
            .rotate(Vector3.X, -lean * 0.7f - run * 2f).rotate(Vector3.Y, -twist * 0.6f)
            .translate(0f, -1.50f, 0f)

        for (side in 0..1) {
            val sx = if (side == 0) -1f else 1f
            val upper = if (side == 0) upperA else upperB
            val fore = if (side == 0) foreA else foreB
            val thigh = if (side == 0) thighA else thighB
            val shin = if (side == 0) shinA else shinB

            // arm: swings opposite to the same-side leg, elbow bends more when running
            val swing = sx * sw * 0.75f + sin(idleT * 1.7f + sx) * 1.4f * idle
            val elbow = -(8f + g * 30f + run * 30f + max(0f, -swing) * 0.5f)
            tmp.set(tor).translate(sx * JackyModels.SHOULDER_X, JackyModels.SHOULDER_Y, 0f)
                .rotate(Vector3.Z, sx * (5f + g * 2f)).rotate(Vector3.X, swing)
            upper.transform.set(tmp)
            fore.transform.set(tmp).translate(0f, -JackyModels.UPPER_ARM_LEN, 0f).rotate(Vector3.X, elbow)

            // leg: thigh swing + knee flexion during the forward swing phase
            val thAng = -sx * sw * 0.72f
            val knee = 3f + min(85f, 8f + a * 1.2f) * max(0f, sx * cw) * blend
            tmp.set(base).translate(sx * JackyModels.HIP_X, hipY - drop, 0f).rotate(Vector3.X, thAng)
            thigh.transform.set(tmp)
            shin.transform.set(tmp).translate(0f, -JackyModels.THIGH_LEN, 0f).rotate(Vector3.X, knee)
        }
    }
}
