package com.desidrive.game

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.Mesh
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.VertexAttributes.Usage
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.attributes.FloatAttribute
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute
import com.badlogic.gdx.graphics.g3d.loader.ObjLoader
import com.badlogic.gdx.graphics.g3d.utils.MeshBuilder
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.math.collision.BoundingBox
import java.util.Random
import kotlin.math.max
import kotlin.math.roundToInt

/** Static-geometry material groups. */
object G {
    const val SOLID = 0
    const val FACADE = 1
    const val ROAD = 2
    const val GROUND = 3
    const val FLAT = 4   // solid colour, never casts shadows
    const val WALK = 5
    const val ASPH = 6
    const val SHOP = 7
}

class ChunkInst(val inst: ModelInstance, val cx: Float, val cy: Float, val cz: Float, val r: Float, val caster: Boolean)
class ExtCar(val model: Model, val scale: Float, val yaw: Float, val cx: Float, val minY: Float, val cz: Float)

object Gfx {
    private val mb = ModelBuilder()
    private val all = ArrayList<Model>()
    private val texs = ArrayList<Texture>()
    private val boxes = HashMap<Int, Model>()
    private val cyls = HashMap<Int, Model>()
    private val spheres = HashMap<Int, Model>()
    private val carModels = HashMap<String, CarModel>()
    private val wheelModels = HashMap<Int, Model>()
    private val extCars = HashMap<String, ExtCar?>()
    private val groupMat = arrayOfNulls<Material>(8)

    val A: Long = (Usage.Position or Usage.Normal).toLong()
    val AT: Long = (Usage.Position or Usage.Normal or Usage.ColorUnpacked or Usage.TextureCoordinates).toLong()

    fun track(m: Model) { all.add(m) }
    fun groupMaterial(g: Int): Material = groupMat[g]!!

    fun mat(c: Color): Material = Material(
        ColorAttribute.createDiffuse(c),
        ColorAttribute.createSpecular(0.22f, 0.22f, 0.22f, 1f),
        FloatAttribute.createShininess(14f)
    )

    // ------------------------------------------------------------ procedural textures
    private fun cl(v: Float) = if (v < 0f) 0f else if (v > 1f) 1f else v

    private fun mk(pm: Pixmap): Texture {
        val t = Texture(pm, true)
        t.setFilter(Texture.TextureFilter.MipMapLinearLinear, Texture.TextureFilter.Linear)
        t.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat)
        pm.dispose()
        texs.add(t)
        return t
    }

    private fun rect(pm: Pixmap, x: Int, y: Int, w: Int, h: Int, r: Float, g: Float, b: Float) {
        pm.setColor(cl(r), cl(g), cl(b), 1f)
        pm.fillRectangle(x, y, w, h)
    }

    private fun grain(pm: Pixmap, amp: Float, rnd: Random) {
        for (y in 0 until pm.height) for (x in 0 until pm.width) {
            val c = Color(pm.getPixel(x, y))
            val n = (rnd.nextFloat() - 0.5f) * amp
            pm.setColor(cl(c.r + n), cl(c.g + n), cl(c.b + n), 1f)
            pm.drawPixel(x, y)
        }
    }

    private fun groundTex(): Texture {
        val n = 128
        val pm = Pixmap(n, n, Pixmap.Format.RGBA8888)
        val rnd = Random(3)
        val g = FloatArray(16 * 16) { rnd.nextFloat() }
        for (y in 0 until n) for (x in 0 until n) {
            val p = g[(y / 8) * 16 + x / 8]
            pm.setColor(cl(0.40f + p * 0.12f), cl(0.38f + p * 0.15f), cl(0.25f + p * 0.05f), 1f)
            pm.drawPixel(x, y)
        }
        grain(pm, 0.09f, rnd)
        return mk(pm)
    }

    private fun asphaltTex(): Texture {
        val n = 128
        val pm = Pixmap(n, n, Pixmap.Format.RGBA8888)
        val rnd = Random(4)
        rect(pm, 0, 0, n, n, 0.21f, 0.21f, 0.22f)
        grain(pm, 0.09f, rnd)
        return mk(pm)
    }

    private fun roadTex(): Texture {
        val w = 128; val h = 256
        val pm = Pixmap(w, h, Pixmap.Format.RGBA8888)
        val rnd = Random(6)
        rect(pm, 0, 0, w, h, 0.21f, 0.21f, 0.22f)
        grain(pm, 0.09f, rnd)
        pm.setColor(0f, 0f, 0f, 0.14f)
        pm.fillRectangle(26, 0, 18, h); pm.fillRectangle(84, 0, 18, h)      // tyre wear
        rect(pm, 5, 0, 3, h, 0.88f, 0.88f, 0.86f)                           // edge lines
        rect(pm, 120, 0, 3, h, 0.88f, 0.88f, 0.86f)
        rect(pm, 62, 0, 4, 128, 0.96f, 0.93f, 0.72f)                        // dashed centre line
        return mk(pm)
    }

    private fun walkTex(): Texture {
        val n = 64
        val pm = Pixmap(n, n, Pixmap.Format.RGBA8888)
        val rnd = Random(8)
        rect(pm, 0, 0, n, n, 0.66f, 0.65f, 0.63f)
        rect(pm, 0, 0, n, 2, 0.45f, 0.45f, 0.44f); rect(pm, 0, 32, n, 2, 0.45f, 0.45f, 0.44f)
        rect(pm, 0, 0, 2, n, 0.45f, 0.45f, 0.44f); rect(pm, 32, 0, 2, n, 0.45f, 0.45f, 0.44f)
        grain(pm, 0.08f, rnd)
        return mk(pm)
    }

    private fun facadeTex(): Texture {
        val n = 128
        val pm = Pixmap(n, n, Pixmap.Format.RGBA8888)
        val rnd = Random(5)
        rect(pm, 0, 0, n, n, 0.93f, 0.92f, 0.90f)
        rect(pm, 0, 114, n, 2, 0.66f, 0.65f, 0.64f)
        rect(pm, 0, 116, n, 12, 0.80f, 0.79f, 0.77f)                          // floor slab
        rect(pm, 30, 16, 68, 70, 0.30f, 0.26f, 0.22f)                         // frame
        for (y in 22 until 80) {                                              // glass gradient
            val t = (y - 22) / 58f
            rect(pm, 36, y, 56, 1, 0.62f - 0.45f * t, 0.78f - 0.55f * t, 0.92f - 0.62f * t)
        }
        rect(pm, 62, 22, 4, 58, 0.34f, 0.30f, 0.26f)                          // mullion
        rect(pm, 36, 48, 56, 3, 0.34f, 0.30f, 0.26f)
        rect(pm, 24, 86, 80, 5, 0.88f, 0.87f, 0.85f)                          // sill
        rect(pm, 26, 91, 76, 3, 0.60f, 0.59f, 0.58f)                          // sill shadow
        rect(pm, 104, 62, 20, 16, 0.82f, 0.82f, 0.84f)                        // AC unit
        rect(pm, 106, 66, 16, 2, 0.40f, 0.40f, 0.42f); rect(pm, 106, 70, 16, 2, 0.40f, 0.40f, 0.42f)
        grain(pm, 0.06f, rnd)
        return mk(pm)
    }

    private fun shopTex(): Texture {
        val n = 128
        val pm = Pixmap(n, n, Pixmap.Format.RGBA8888)
        val rnd = Random(9)
        rect(pm, 0, 0, n, n, 0.90f, 0.88f, 0.84f)
        rect(pm, 0, 0, n, 34, 0.98f, 0.98f, 0.98f)                            // sign band
        rect(pm, 0, 32, n, 3, 0.30f, 0.30f, 0.32f)
        for (i in 0 until 7) rect(pm, 10 + i * 16, 10, 10, 14, 0.14f, 0.14f, 0.2f)
        var y = 40
        while (y < 112) {                                                     // roller shutter
            rect(pm, 6, y, 62, 3, 0.64f, 0.64f, 0.66f)
            rect(pm, 6, y + 3, 62, 1, 0.40f, 0.40f, 0.42f)
            y += 4
        }
        rect(pm, 76, 44, 46, 66, 0.18f, 0.22f, 0.28f)                         // shop glass
        rect(pm, 80, 48, 38, 20, 0.55f, 0.70f, 0.82f)
        rect(pm, 0, 112, n, 16, 0.38f, 0.38f, 0.40f)                          // plinth
        grain(pm, 0.06f, rnd)
        return mk(pm)
    }

    fun setup() {
        fun m(tex: Texture?, sp: Float, sh: Float): Material {
            val mt = Material(
                ColorAttribute.createDiffuse(Color.WHITE),
                ColorAttribute.createSpecular(sp, sp, sp, 1f),
                FloatAttribute.createShininess(sh)
            )
            if (tex != null) mt.set(TextureAttribute.createDiffuse(tex))
            return mt
        }
        groupMat[G.SOLID] = m(null, 0.22f, 14f)
        groupMat[G.FLAT] = m(null, 0.10f, 8f)
        groupMat[G.FACADE] = m(facadeTex(), 0.30f, 26f)
        groupMat[G.SHOP] = m(shopTex(), 0.25f, 20f)
        groupMat[G.ROAD] = m(roadTex(), 0.08f, 6f)
        groupMat[G.ASPH] = m(asphaltTex(), 0.08f, 6f)
        groupMat[G.GROUND] = m(groundTex(), 0.02f, 4f)
        groupMat[G.WALK] = m(walkTex(), 0.10f, 8f)
    }

    // ------------------------------------------------------------ unit models (people, beam)
    fun box(c: Color): ModelInstance {
        val m = boxes.getOrPut(c.toIntBits()) {
            val x = mb.createBox(1f, 1f, 1f, mat(c), A); all.add(x); x
        }
        return ModelInstance(m)
    }

    fun cyl(c: Color): ModelInstance {
        val m = cyls.getOrPut(c.toIntBits()) {
            val x = mb.createCylinder(1f, 1f, 1f, 16, mat(c), A); all.add(x); x
        }
        return ModelInstance(m)
    }

    fun sphere(c: Color): ModelInstance {
        val m = spheres.getOrPut(c.toIntBits()) {
            val x = mb.createSphere(1f, 1f, 1f, 14, 10, mat(c), A); all.add(x); x
        }
        return ModelInstance(m)
    }

    /** Translucent mission beam. */
    fun beam(c: Color, alpha: Float): ModelInstance {
        val m = mb.createCylinder(
            1f, 1f, 1f, 18,
            Material(ColorAttribute.createDiffuse(c), BlendingAttribute(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA, alpha)),
            A
        )
        all.add(m)
        return ModelInstance(m)
    }

    fun put(
        i: ModelInstance, x: Float, y: Float, z: Float, yaw: Float,
        lx: Float, ly: Float, lz: Float,
        sx: Float, sy: Float, sz: Float, roll: Float = 0f
    ) {
        i.transform.idt().translate(x, y, z).rotate(Vector3.Y, yaw).translate(lx, ly, lz)
        if (roll != 0f) i.transform.rotate(Vector3.Z, roll)
        i.transform.scale(sx, sy, sz)
    }

    // ------------------------------------------------------------ cars
    fun carModel(spec: CarSpec, c: Color): CarModel =
        carModels.getOrPut(spec.name + c.toIntBits()) { CarBuilder.build(spec, c) }

    fun wheelModel(r: Float): Model =
        wheelModels.getOrPut((r * 1000f).toInt()) { val w = CarBuilder.wheel(r); all.add(w); w }

    /**
     * Optional real car models: put assets/models/sedan.obj, suv.obj, supercar.obj, auto.obj
     * (front of the car must face +Z). If the file exists it replaces the built-in model.
     */
    fun externalCar(spec: CarSpec): ExtCar? {
        val name = spec.file
        if (name.isEmpty()) return null
        if (extCars.containsKey(name)) return extCars[name]
        var res: ExtCar? = null
        try {
            val fh = Gdx.files.internal("models/$name.obj")
            if (fh.exists()) {
                val model = ObjLoader().loadModel(fh)
                all.add(model)
                val bb = model.calculateBoundingBox(BoundingBox())
                val dim = Vector3(); val ctr = Vector3()
                bb.getDimensions(dim); bb.getCenter(ctr)
                val longSide = max(dim.x, dim.z)
                val yaw = if (dim.x > dim.z) 90f else 0f
                res = ExtCar(model, spec.len / longSide, yaw, ctr.x, bb.min.y, ctr.z)
            }
        } catch (e: Exception) { res = null }
        extCars[name] = res
        return res
    }

    fun dispose() {
        for (m in all) m.dispose()
        for (t in texs) t.dispose()
    }
}

/** Merges all static world geometry into a handful of big meshes per 64m cell (huge FPS win). */
class StaticBuilder {
    private val cur = HashMap<Long, MeshBuilder>()
    private val finished = ArrayList<Pair<Long, Mesh>>()
    private val m = Matrix4()
    private val va = MeshPartBuilder.VertexInfo()
    private val vb = MeshPartBuilder.VertexInfo()
    private val vc = MeshPartBuilder.VertexInfo()
    private val vd = MeshPartBuilder.VertexInfo()
    private val t1 = Vector3()
    private val t2 = Vector3()
    private val t3 = Vector2()

    private fun key(x: Float, z: Float, g: Int): Long {
        val cx = Math.floor(((x + 256f) / 64f).toDouble()).toInt().coerceIn(0, 7)
        val cz = Math.floor(((z + 256f) / 64f).toDouble()).toInt().coerceIn(0, 7)
        return (cx * 8 + cz) * 16L + g
    }

    private fun bld(x: Float, z: Float, g: Int): MeshBuilder {
        val k = key(x, z, g)
        var b = cur[k]
        if (b != null && b.numVertices > 45000) {
            finished.add(Pair(k, b.end()))
            cur.remove(k)
            b = null
        }
        if (b == null) {
            b = MeshBuilder()
            b.begin(Gfx.AT, GL20.GL_TRIANGLES)
            cur[k] = b
        }
        return b
    }

    private fun vi(v: MeshPartBuilder.VertexInfo, x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float, c: Color, u: Float, w: Float) {
        v.set(t1.set(x, y, z), t2.set(nx, ny, nz), c, t3.set(u, w))
    }

    fun box(g: Int, c: Color, cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, yaw: Float = 0f) {
        val b = bld(cx, cz, g); b.setColor(c)
        m.idt().translate(cx, cy, cz)
        if (yaw != 0f) m.rotate(Vector3.Y, yaw)
        b.setVertexTransform(m); b.box(sx, sy, sz); b.setVertexTransform(null)
    }

    fun cyl(g: Int, c: Color, cx: Float, cy: Float, cz: Float, dx: Float, h: Float, dz: Float) {
        val b = bld(cx, cz, g); b.setColor(c)
        m.idt().translate(cx, cy, cz)
        b.setVertexTransform(m); b.cylinder(dx, h, dz, 14); b.setVertexTransform(null)
    }

    fun cone(g: Int, c: Color, cx: Float, cy: Float, cz: Float, dx: Float, h: Float, dz: Float) {
        val b = bld(cx, cz, g); b.setColor(c)
        m.idt().translate(cx, cy, cz)
        b.setVertexTransform(m); b.cone(dx, h, dz, 14); b.setVertexTransform(null)
    }

    fun sphere(g: Int, c: Color, cx: Float, cy: Float, cz: Float, dx: Float, dy: Float, dz: Float) {
        val b = bld(cx, cz, g); b.setColor(c)
        m.idt().translate(cx, cy, cz)
        b.setVertexTransform(m); b.sphere(dx, dy, dz, 10, 8); b.setVertexTransform(null)
    }

    /** Horizontal quad (normal up). swap=true makes U run along Z instead of X. */
    fun flat(g: Int, c: Color, x0: Float, z0: Float, x1: Float, z1: Float, y: Float,
             u0: Float, v0: Float, u1: Float, v1: Float, swap: Boolean = false) {
        val b = bld((x0 + x1) * 0.5f, (z0 + z1) * 0.5f, g)
        fun uu(fx: Int, fz: Int) = if (!swap) u0 + fx * (u1 - u0) else u0 + fz * (u1 - u0)
        fun ww(fx: Int, fz: Int) = if (!swap) v0 + fz * (v1 - v0) else v0 + fx * (v1 - v0)
        vi(va, x0, y, z0, 0f, 1f, 0f, c, uu(0, 0), ww(0, 0))
        vi(vb, x0, y, z1, 0f, 1f, 0f, c, uu(0, 1), ww(0, 1))
        vi(vc, x1, y, z1, 0f, 1f, 0f, c, uu(1, 1), ww(1, 1))
        vi(vd, x1, y, z0, 0f, 1f, 0f, c, uu(1, 0), ww(1, 0))
        b.rect(va, vb, vc, vd)
    }

    /** Four textured walls; the texture repeats a whole number of times per wall. */
    fun facade(g: Int, c: Color, cx: Float, cz: Float, w: Float, d: Float, y0: Float, y1: Float, tw: Float, th: Float) {
        val b = bld(cx, cz, g)
        val rows = max(1f, ((y1 - y0) / th).roundToInt().toFloat())
        val cw = max(1f, (w / tw).roundToInt().toFloat())
        val cd = max(1f, (d / tw).roundToInt().toFloat())
        val hw = w / 2f; val hd = d / 2f
        wall(b, c, cx - hw, cz + hd, cx + hw, cz + hd, 0f, 1f, y0, y1, cw, rows, true)
        wall(b, c, cx + hw, cz - hd, cx - hw, cz - hd, 0f, -1f, y0, y1, cw, rows, true)
        wall(b, c, cx + hw, cz + hd, cx + hw, cz - hd, 1f, 0f, y0, y1, cd, rows, false)
        wall(b, c, cx - hw, cz - hd, cx - hw, cz + hd, -1f, 0f, y0, y1, cd, rows, false)
    }

    private fun wall(b: MeshBuilder, c: Color, ax: Float, az: Float, bx: Float, bz: Float,
                     nx: Float, nz: Float, y0: Float, y1: Float, cols: Float, rows: Float, unused: Boolean) {
        vi(va, ax, y0, az, nx, 0f, nz, c, 0f, rows)
        vi(vb, bx, y0, bz, nx, 0f, nz, c, cols, rows)
        vi(vc, bx, y1, bz, nx, 0f, nz, c, cols, 0f)
        vi(vd, ax, y1, az, nx, 0f, nz, c, 0f, 0f)
        b.rect(va, vb, vc, vd)
    }

    fun finish(): ArrayList<ChunkInst> {
        for ((k, b) in cur) finished.add(Pair(k, b.end()))
        cur.clear()
        val out = ArrayList<ChunkInst>()
        val ctr = Vector3(); val dim = Vector3()
        for ((k, mesh) in finished) {
            val g = (k % 16L).toInt()
            val bb = mesh.calculateBoundingBox()
            bb.getCenter(ctr); bb.getDimensions(dim)
            val mdl = ModelBuilder()
            mdl.begin()
            mdl.part("chunk$k", mesh, GL20.GL_TRIANGLES, Gfx.groupMaterial(g))
            val model = mdl.end()
            Gfx.track(model)
            val caster = g == G.SOLID || g == G.FACADE || g == G.SHOP
            out.add(ChunkInst(ModelInstance(model), ctr.x, ctr.y, ctr.z, dim.len() * 0.5f, caster))
        }
        finished.clear()
        return out
    }
}
